import { systemPrompt, rateLimited } from "@/lib/knowledge";
export const runtime = "nodejs";
const json = (o, s = 200) => Response.json(o, { status: s });
export async function POST(req) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0] || "local";
  if (rateLimited(ip)) return json({ error: "Too many messages. Wait a minute and try again." }, 429);
  const key = process.env.GEMINI_API_KEY;
  if (!key || key === "your_api_key_here") return json({ error: "The assistant isn't configured yet (missing GEMINI_API_KEY)." }, 503);
  let body; try { body = await req.json(); } catch { return json({ error: "Invalid request." }, 400); }
  const msgs = Array.isArray(body.messages) ? body.messages.slice(-10) : [];
  const ok = msgs.length && msgs.every((m) => ["user", "assistant"].includes(m.role) && typeof m.text === "string" && m.text.length <= 600);
  if (!ok || msgs[msgs.length - 1].role !== "user") return json({ error: "Messages must be under 600 characters." }, 400);
  try {
    const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: systemPrompt }] },
        contents: msgs.map((m) => ({ role: m.role === "user" ? "user" : "model", parts: [{ text: m.text }] })),
        generationConfig: { maxOutputTokens: 500, temperature: 0.4 } }),
    });
    if (!r.ok) return json({ error: "The AI service returned an error. Try again shortly." }, 502);
    const d = await r.json();
    const text = d.candidates?.[0]?.content?.parts?.map((p) => p.text).join("") || "";
    return json({ text: text || "I couldn't generate a reply. Try rephrasing." });
  } catch { return json({ error: "Couldn't reach the AI service." }, 502); }
}
